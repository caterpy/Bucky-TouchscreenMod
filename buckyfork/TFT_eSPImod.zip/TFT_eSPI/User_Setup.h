#ifndef USER_SETUP_LOADED
#define USER_SETUP_LOADED

// =====================================================
// ESP32-2432S028R Cheap Yellow Display
// 2.8-inch ILI9341, 240x320
// =====================================================

#define USER_SETUP_ID 2432

// Display controller
#define ILI9341_2_DRIVER

// Native portrait dimensions
#define TFT_WIDTH  240
#define TFT_HEIGHT 320

// TFT SPI pins
#define TFT_MISO 12
#define TFT_MOSI 13
#define TFT_SCLK 14
#define TFT_CS   15
#define TFT_DC    2
#define TFT_RST  -1

// Backlight
#define TFT_BL 21
#define TFT_BACKLIGHT_ON HIGH

// TFT uses the ESP32 HSPI peripheral
#define USE_HSPI_PORT

// Fonts
#define LOAD_GLCD
#define LOAD_FONT2
#define LOAD_FONT4

// SPI speeds
#define SPI_FREQUENCY       40000000
#define SPI_READ_FREQUENCY  20000000

#endif